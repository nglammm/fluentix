# Fluentix Docs: TEST PACKAGE
## _Hello!_

[![N|Solid](https://i.ibb.co/sHF7y3D/Powered-by-the-Fluentix-GROUP.png)](http://fluentix.dev)

---
## Welcome!
This is a test package! Haha, it's very useful when in.... development.
This package existed on a purpose of testing the implementations of the uploadings as well as how well it can handle search requests on the web. 

## Features:
- Useless for you but useful for me since we can see if it's working or not.
- Don't download man.

## Usage:
- It can't do anything really =D

## Known issues:
- It can't display charts (the boards) of the markdown file to the display of the package.

## Feedbacks:
Please report us at http://fluentix.dev if you got any problems.

## Credits"
- [@Lam](http://mrlam.dev) - The one who implemented the packages thing.

---

Docs by: [@Lam](http://mrlam.dev), One of the Fluentix developer.

